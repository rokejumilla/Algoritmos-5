#include "raylib.h"
#include <string>
#include <cmath>
#include <iostream>
#include <ctime>

constexpr int SCREEN_WIDTH = 800;
constexpr int SCREEN_HEIGHT = 600;
constexpr int TARGET_FPS = 60;

constexpr float BALL_RADIUS = 18.0f;
constexpr float BALL_SPEED = 220.0f;

const std::string BALL_SPRITE_PATH = R"(C:\Users\santino\Downloads\Raylib-vs2022 Limpio (2)\Raylib-vs2022 Limpio\source\logo.png)";

constexpr float TIME_SCALE_MIN = 0.1f;
constexpr float TIME_SCALE_MAX = 3.0f;
constexpr float TIME_SCALE_CHANGE_RATE = 0.6f;

struct Ball {
    Vector2 pos;
    Vector2 vel;
    float speed;
    Texture2D tex;
    float radius;
};

Ball ball{};
float timeScale = 1.0f;
bool closeRequested = false;

static Vector2 normalizeSafe(Vector2 v) {
    float len = sqrtf(v.x * v.x + v.y * v.y);
    if (len <= 1e-6f) return { 0.0f, 0.0f };
    return { v.x / len, v.y / len };
}

static float randomFloat(float minv, float maxv) {
    int imin = (int)floorf(minv * 1000.0f);
    int imax = (int)ceilf(maxv * 1000.0f);
    if (imax < imin) imax = imin;
    int r = GetRandomValue(imin, imax);
    return r / 1000.0f;
}

static void setRandomDirectionAwayFromEdge(Ball& b, int collidedEdge) {
    Vector2 dir = { 0,0 };
    switch (collidedEdge) {
    case 0:
        dir.x = randomFloat(0.4f, 1.0f);
        dir.y = randomFloat(-1.0f, 1.0f);
        break;
    case 1:
        dir.x = -randomFloat(0.4f, 1.0f);
        dir.y = randomFloat(-1.0f, 1.0f);
        break;
    case 2:
        dir.x = randomFloat(-1.0f, 1.0f);
        dir.y = randomFloat(0.4f, 1.0f);
        break;
    case 3:
        dir.x = randomFloat(-1.0f, 1.0f);
        dir.y = -randomFloat(0.4f, 1.0f);
        break;
    default:
        dir = { randomFloat(-1.0f,1.0f), randomFloat(-1.0f,1.0f) };
        break;
    }
    dir = normalizeSafe(dir);
    b.vel = { dir.x * b.speed, dir.y * b.speed };
}

static void loadBallSprite(Ball& b, const std::string& path) {
    b.tex = LoadTexture(path.c_str());
    if (b.tex.id == 0) {
        std::cerr << "[WARN] No se pudo cargar sprite de pelota en: " << path << "  -> fallback a c�rculo.\n";
        std::cerr << "[WARN] Ruta absoluta usada; para portabilidad considera usar ruta relativa (assets/logo.png) dentro del proyecto.\n";
    }
    else {
        std::cerr << "[INFO] Sprite pelota cargado: " << path << " (" << b.tex.width << "x" << b.tex.height << ")\n";
    }
}

static void initResources() {
    InitWindow(SCREEN_WIDTH, SCREEN_HEIGHT, "Ejercicio - INIT/FRAME/EVENT/UPDATE/DRAW - Pelotita");
    SetTargetFPS(TARGET_FPS);

    SetRandomSeed((unsigned)time(NULL));

    ball.pos = { SCREEN_WIDTH * 0.5f, SCREEN_HEIGHT * 0.5f };
    Vector2 rnd = { randomFloat(-1.0f, 1.0f), randomFloat(-1.0f, 1.0f) };
    rnd = normalizeSafe(rnd);
    ball.speed = BALL_SPEED;
    ball.vel = { rnd.x * ball.speed, rnd.y * ball.speed };
    ball.radius = BALL_RADIUS;
    ball.tex.id = 0;

    loadBallSprite(ball, BALL_SPRITE_PATH);
}

static void unloadResources() {
    if (ball.tex.id != 0) UnloadTexture(ball.tex);
    CloseWindow();
}

static void processInput(float dt) {
    if (IsKeyDown(KEY_UP)) {
        timeScale += TIME_SCALE_CHANGE_RATE * dt;
        if (timeScale > TIME_SCALE_MAX) timeScale = TIME_SCALE_MAX;
    }
    if (IsKeyDown(KEY_DOWN)) {
        timeScale -= TIME_SCALE_CHANGE_RATE * dt;
        if (timeScale < TIME_SCALE_MIN) timeScale = TIME_SCALE_MIN;
    }

    if (IsKeyPressed(KEY_ESCAPE)) {
        closeRequested = true;
    }
}

static void updateBall(float dt) {
    float effectiveDt = dt * timeScale;

    ball.pos.x += ball.vel.x * effectiveDt;
    ball.pos.y += ball.vel.y * effectiveDt;

    bool collided = false;
    if (ball.pos.x - ball.radius <= 0.0f) {
        ball.pos.x = ball.radius;
        setRandomDirectionAwayFromEdge(ball, 0);
        collided = true;
    }
    if (ball.pos.x + ball.radius >= SCREEN_WIDTH) {
        ball.pos.x = SCREEN_WIDTH - ball.radius;
        setRandomDirectionAwayFromEdge(ball, 1);
        collided = true;
    }
    if (ball.pos.y - ball.radius <= 0.0f) {
        ball.pos.y = ball.radius;
        setRandomDirectionAwayFromEdge(ball, 2);
        collided = true;
    }
    if (ball.pos.y + ball.radius >= SCREEN_HEIGHT) {
        ball.pos.y = SCREEN_HEIGHT - ball.radius;
        setRandomDirectionAwayFromEdge(ball, 3);
        collided = true;
    }

    (void)collided;
}

static void drawGame() {
    BeginDrawing();
    ClearBackground(RAYWHITE);

    if (ball.tex.id != 0) {
        Rectangle src = { 0.0f, 0.0f, (float)ball.tex.width, (float)ball.tex.height };
        Rectangle dest = { ball.pos.x - ball.radius, ball.pos.y - ball.radius, ball.radius * 2.0f, ball.radius * 2.0f };
        Vector2 origin = { 0.0f, 0.0f };
        DrawTexturePro(ball.tex, src, dest, origin, 0.0f, WHITE);
    }
    else {
        DrawCircleV(ball.pos, ball.radius, MAROON);
    }

    const int hudY = 10;
    DrawText(TextFormat("FPS: %d", GetFPS()), 10, hudY, 16, BLACK);
    DrawText(TextFormat("Ball X: %.1f  Y: %.1f", ball.pos.x, ball.pos.y), 110, hudY, 16, BLACK);
    DrawText(TextFormat("timeScale: %.2f (mant�n ARRIBA/ABAJO)", timeScale), 360, hudY, 16, DARKGRAY);

    DrawText("ARRIBA/DOWN: Aumentar/Disminuir velocidad del juego (mant�n la tecla)", 10, SCREEN_HEIGHT - 28, 14, DARKGRAY);
    DrawText("ESC: Salir", SCREEN_WIDTH - 100, SCREEN_HEIGHT - 28, 14, DARKGRAY);

    EndDrawing();
}

int main() {
    initResources();

    while (!WindowShouldClose() && !closeRequested) {
        float dt = GetFrameTime();

        processInput(dt);
        updateBall(dt);
        drawGame();
    }

    unloadResources();
    return 0;
}
